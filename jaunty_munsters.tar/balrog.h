#pragma once
#include "demon.h"
#include "balrog.h"

using namespace std;

class Balrog : public Demon {
private:
      // nothing private
protected:

public:
      Balrog();
      int getDamage();
};
