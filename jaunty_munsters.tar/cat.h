#include "creature.h"
#pragma once

using namespace std;

class Cat : public Creature {

public:

      Cat();
      int getDamage();
};
