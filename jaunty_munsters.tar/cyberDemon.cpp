#include "cyberDemon.h"

CyberDemon::CyberDemon() {
      type = "cyberDemon"; // Human, CyberDemon, Balrog, Elf, Cat
      name = "Joe";
      strength = 15;
      hitpoints = 300;
      payoff = 100;
      cost = 300;
}
